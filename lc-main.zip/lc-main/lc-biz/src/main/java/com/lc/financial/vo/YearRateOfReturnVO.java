package com.lc.financial.vo;

import lombok.Data;

@Data
public class YearRateOfReturnVO {

	private Double value;

	private String theDate;
	
}
