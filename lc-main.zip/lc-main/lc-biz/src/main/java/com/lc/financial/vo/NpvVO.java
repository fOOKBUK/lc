package com.lc.financial.vo;

import lombok.Data;

@Data
public class NpvVO {
	
	private Double value;

	private String theDate;
	
	private Double chg;

}
