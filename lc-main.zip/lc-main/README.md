## 介绍

该项目基于Java开发。 

* 后端采用Spring Boot、Spring Data Jpa、Sa Token、 Redis、Mysql。
* 前端采用uniapp跨端开发，一套代码，可发布到iOS、Android、Web（响应式）等多个平台。
* 增加实名认证时手写签名板
* 本项目主要供交流学习，请不要用于商业项目。

## 联系我们
如需获取最新版本,请联系我们：纸飞机 Telegram：[licaiguwen0](https://t.me/licaiguwen0)

## 在线体验
  
## h5版本：http://192.253.230.185:8090
测试账号：13533333333，密码：123，支付密码：123456 也可以自行注册账号

## 运营后台：http://192.253.230.185:8089
测试账号：admin，密码：123


## 演示图
<table>
    <tr>
        <td><img src="https://github.com/fOOKBUK/lc/blob/main/lc2409/1.jpg"/></td>
        <td><img src="https://github.com/fOOKBUK/lc/blob/main/lc2409/2.jpg"/></td>
<td><img src="https://github.com/fOOKBUK/lc/blob/main/lc2409/3.jpg"/></td>
    </tr>
<tr>
        <td><img src="https://github.com/fOOKBUK/lc/blob/main/lc2409/4.jpg"/></td>
        <td><img src="https://github.com/fOOKBUK/lc/blob/main/lc2409/5.jpg"/></td>
<td><img src="https://github.com/fOOKBUK/lc/blob/main/lc2409/6.jpg"/></td>
    </tr>
<tr>
        <td><img src="https://github.com/fOOKBUK/lc/blob/main/lc2409/7.jpg"/></td>
        <td><img src="https://github.com/fOOKBUK/lc/blob/main/lc2409/8.jpg"/></td>
<td><img src="https://github.com/fOOKBUK/lc/blob/main/lc2409/9.jpg"/></td>
    </tr>
	 
</table>



